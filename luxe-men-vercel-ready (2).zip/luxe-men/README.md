# LUXE MEN — Premium Men's Fashion & Accessories E-Commerce Store

> **"DEFINE YOUR STYLE"** — A complete, polished, modern, and fully responsive e-commerce storefront for a high-end men's fashion and accessories brand. Built with React, Vite, and custom luxury design systems.

---

## 💎 Project Highlights

- **Aesthetic**: Premium dark luxury palette with charcoal (`#0F1012`), ivory (`#F9F8F6`), and muted champagne gold accents (`#C5A880`).
- **Typography**: Editorial serif typography for headings (`Cinzel` & `Playfair Display`) paired with clean modern sans-serif (`Plus Jakarta Sans`).
- **Zero Placeholder UI**: Over 16 realistic curated luxury products across Watches, Bags, Footwear, and Accessories with authentic prices, detailed materials, dimensions, and care guides.
- **Frontend Architecture**: Fast, lightweight React + Vite architecture with centralized state management (`ShopContext`) and persistent browser `localStorage`.
- **Deployment Ready**: Builds into an optimized static bundle ready for immediate deployment to Vercel, Netlify, GitHub Pages, or Cloudflare Pages.

---

## 🏛️ Pages & Route Hierarchy

| Route | Page | Description |
|---|---|---|
| `/` | **Home** | Slim Announcement Bar, Sticky Glassmorphism Header, Hero, Shop by Category, New Arrivals (8 cards), Promotional Banner, Best Sellers (4 cards), Why Luxe Men, Customer Testimonials, Newsletter, 4-Column Footer. |
| `/shop` | **Shop All** | Interactive faceted filters (Category, Price ranges: Under $50, $50–$100, $100–$150, $150+), real-time search, sorting (Featured, Price Low-High, Price High-Low, Newest, Best Selling), Clear Filters, and responsive grid. |
| `/new-arrivals` | **New Arrivals** | Dedicated showcase for fresh drops and seasonal releases with instant filtering and search. |
| `/collections` | **Collections** | Editorial presentation of the 4 flagship capsules: *Essential Classics*, *Modern Accessories*, *Weekend Edit*, and *Executive Collection*. |
| `/product/:id` | **Product Details** | Interactive thumbnail gallery, color pills, size selector, quantity adjuster, Add to Cart, Buy Now, Wishlist toggle, specifications accordion (Materials, Shipping & Returns, Care), and related curated pairings. |
| `/cart` | **Shopping Bag** | Dedicated full cart page with line items, dynamic quantity adjustment, live subtotal, and free shipping progress meter. |
| `/checkout` | **Checkout Demo** | Professional multi-step checkout form (Contact, Shipping, Demo Payment Form) with simulated encrypted order confirmation view. |
| `/wishlist` | **Wishlist** | Saved favorite pieces with one-click Add to Cart, removal, and empty state guidance. |
| `/about` | **About** | Brand narrative exploring *Our Story*, *Our Philosophy*, and *Our Mission*. |
| `/contact` | **Contact** | Concierge advisory details, showroom hours, and demo message submission form with toast confirmation. |
| `/faq` | **FAQs** | Smooth collapsible accordion covering delivery timelines, authenticity guarantees, returns, and support. |
| `/privacy-policy` | **Privacy Policy** | Professional legal demo policy. |
| `/terms` | **Terms & Conditions** | Transparent terms of service for the demonstration store. |
| `/shipping-policy` | **Shipping Policy** | Tiered worldwide delivery timelines and packaging details. |
| `/return-policy` | **Return Policy** | 30-day luxury return and exchange guidelines. |
| `*` | **404 Not Found** | Custom high-end "Page Not Found" screen with instant redirection back to home. |

---

## ⚡ Interactive Frontend Features

1. **Slide-Out Cart Drawer**: Accessible from the header shopping bag icon; features quantity increment/decrement, free shipping progress bar ($100 threshold), item deletion, and direct checkout CTA.
2. **Quick View Modal**: Instant preview pop-up on product card hover with gallery view, color/size selection, and quick Add to Cart.
3. **Live Search Dialog**: Modal search with real-time keyword filtering across names, categories, and descriptions, plus quick tag suggestions.
4. **Interactive Wishlist**: Heart toggle on every product card and detail page; badge updates in real time with localStorage persistence.
5. **Toast Notifications**: Non-intrusive luxury feedback toasts when items are added to cart, saved to wishlist, or newsletter/contact forms are submitted.
6. **Sticky Header & Back-to-Top**: Header transitions smoothly with scroll blur; subtle floating back-to-top button appears upon page descent.
7. **Mobile Drawer Menu**: Smooth animated side drawer with navigation links, search trigger, wishlist count, and bag access.

---

## 🚀 Running the Project Locally

### 1. Installation
Ensure Node.js (v18+) is installed. Run:
```bash
npm install
```

### 2. Development Mode
Start the Vite development server:
```bash
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

### 3. Production Build & Preview
To validate and preview the optimized production build:
```bash
npm run build
npm run preview
```
Open [http://localhost:4173](http://localhost:4173) in your browser.

---

## 🌐 Deploying to Live Hosting

The project produces pure standard static assets in the `dist/` directory upon running `npm run build`.

### Vercel
1. Push the repository to GitHub (do **not** commit `node_modules` or `dist`).
2. Import the repository in [Vercel](https://vercel.com).
3. Framework Preset: **Vite** (auto-detected).
4. Build Command: `npm run build` | Output Directory: `dist`.
5. `vercel.json` already rewrites every route to `index.html`, so direct links and page refreshes (e.g. `/shop`, `/product/oxford-leather-shoes`) work.

### Netlify
1. Drag and drop the `dist/` folder into Netlify Drop, or connect via Git.
2. Build Command: `npm run build` | Publish directory: `dist`.

---

## 📁 Project Structure

```
luxe-men/
├── index.html                   # HTML entry point with Google Fonts & SEO meta tags
├── package.json                 # Project dependencies and build scripts
├── vite.config.js               # Vite bundler configuration
├── vercel.json                  # Vercel config: SPA rewrite so /shop, /product/:id work on refresh
├── public/                      # Static assets
└── src/
    ├── main.jsx                 # React root renderer
    ├── App.jsx                  # Main application router and layout manager
    ├── index.css                # Master luxury CSS design system
    ├── context/
    │   └── ShopContext.jsx      # Global state (Cart, Wishlist, Modals, Routing, Toasts)
    ├── data/
    │   └── products.js          # Centralized products, categories, capsules, testimonials, FAQs
    ├── components/
    │   ├── AnnouncementBar.jsx  # Closeable top announcement banner
    │   ├── Navbar.jsx           # Sticky glassmorphism header
    │   ├── MobileMenu.jsx       # Slide-out navigation drawer for mobile
    │   ├── HeroSection.jsx      # "DEFINE YOUR STYLE" hero showcase
    │   ├── CategorySection.jsx  # "SHOP BY CATEGORY" 4-card interactive grid
    │   ├── ProductCard.jsx      # Interactive product card with badges, quick view, wishlist
    │   ├── ProductGrid.jsx      # Responsive 4-col/3-col/2-col/1-col grid
    │   ├── PromoBanner.jsx      # "YOUR STYLE. YOUR SIGNATURE" promotional section
    │   ├── BestSellers.jsx      # "BEST SELLERS" 4 top iconic pieces
    │   ├── WhyLuxeMen.jsx       # 4 brand benefit cards with icons
    │   ├── CustomerReviews.jsx  # Testimonials with 5-star visual ratings
    │   ├── Newsletter.jsx       # "STAY IN THE LOOP" subscription component
    │   ├── Footer.jsx           # 4-column luxury footer with social links & copyright
    │   ├── CartDrawer.jsx       # Slide-out shopping bag drawer
    │   ├── QuickViewModal.jsx   # Product quick view modal
    │   ├── SearchModal.jsx      # Live search modal with keyword tags
    │   ├── ToastContainer.jsx   # Floating toast notification system
    │   ├── BackToTop.jsx        # Floating smooth scroll button
    │   ├── Breadcrumbs.jsx      # Reusable breadcrumb trail
    │   └── Icons.jsx            # Custom crisp SVG luxury icons set
    └── pages/
        ├── HomePage.jsx         # Exact requested section order
        ├── ShopPage.jsx         # Full shop with filters, price ranges, search, sorting
        ├── ProductDetailsPage.jsx # Product detail view with gallery & specifications
        ├── NewArrivalsPage.jsx  # Dedicated fresh drops page
        ├── CollectionsPage.jsx  # Dedicated 4-capsule collections page
        ├── AboutPage.jsx        # Our Story, Philosophy, and Mission
        ├── ContactPage.jsx      # Client advisory details & contact form
        ├── CartPage.jsx         # Dedicated full shopping bag view
        ├── CheckoutPage.jsx     # Multi-step demo checkout & order confirmation
        ├── FAQPage.jsx          # Interactive expandable FAQ accordions
        ├── WishlistPage.jsx     # Saved favorites view
        ├── PolicyPages.jsx      # Privacy, Terms, Shipping, Return policies
        └── NotFoundPage.jsx     # 404 Page Not Found screen
```

---

© 2026 **LUXE MEN**. All rights reserved.
